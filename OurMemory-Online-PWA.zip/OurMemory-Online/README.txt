OURMEMORY ONLINE

1. buat project Supabase.
2. buka SQL Editor dan jalankan SETUP-SUPABASE.sql.
3. di index.html ganti SUPABASE_URL dan SUPABASE_ANON_KEY.
4. upload index.html, manifest.json, sw.js ke Vercel/hosting.
5. daftar memakai email + password.

PENTING: gunakan hanya anon/publishable key di browser, jangan service_role key.
RLS membatasi edit/hapus berdasarkan user_id pemilik.
Media dibuat publik untuk kebutuhan galeri bersama; jangan upload media yang ingin benar-benar rahasia pada versi ini.
